
<div class="main">
    <div class="page_where_l"><a href="/" rel="nofollow">Home</a> - <a href="/wholesale/" rel="nofollow">Products</a> - [<a href="/wholesale/brand-obdstar/">OBDSTAR</a>] - <a href="/wholesale/original-brand-tool/">Original Brand Tool</a> - OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL</div><div class="page_where_r"><a href="javascript:history.go(-1);" rel="nofollow">&laquo; Go Back</a></div>
    <div class="blank8px"></div>

    <div class="ms_f_m">
        <div itemscope itemtype="http://schema.org/Product">
            <meta itemprop="name" content="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" />
            <meta itemprop="sku" content="HKSP283" />
            <div itemprop="offers" itemscope itemtype="http://schema.org/Offer">
                <meta itemprop="priceCurrency" content="USD" />
                <meta itemprop="price" content="999.00" />
                <meta itemprop="availability" itemtype="http://schema.org/ItemAvailability" content="http://schema.org/InStock"/>
                <meta itemprop="itemCondition" itemtype="http://schema.org/OfferItemCondition" content="http://schema.org/NewCondition"/>
            </div>
            <div itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
                <meta itemprop="ratingValue" content="4.8" />
                <meta itemprop="bestRating" content="5" />
                <meta itemprop="reviewCount" content="55" />
            </div>
        </div>
        <div class="pro_chief">
            <div class="pro_chf_photo">
                <div class="pro_chf_photo_view" onmouseover="javascript:document.getElementById('pro_chf_pv_arr_zoom').style.display='';" onmouseout="javascript:document.getElementById('pro_chf_pv_arr_zoom').style.display='none';"><a href="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-1.3.jpg" title="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" target="_blank" id="hrefProImg"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-1.3.jpg" width="500" height="500" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" id="proPicView" /></a></div><div class="pro_chf_pv_arr_zoom" id="pro_chf_pv_arr_zoom" style="display:none"><span>View Larger Image</span></div><div class="blank10px"></div><div class="pro_chf_photo_more" id="pro_chf_photo_more" style="width:510px;"><div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-1.3.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-1.3.jpg';"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-1.3.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-1.3.jpg" /> </a></div></div>
                    <div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-3.1.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-3.1.jpg';"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-3.1.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-3.1.jpg" /> </a></div></div>
                    <div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300-dp-1.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300-dp-1.jpg';"><img src="/upload/pro/obdstar-x300-dp-1.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300-dp-1.jpg" /> </a></div></div>
                    <div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-3.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-3.jpg';"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-3.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-3.jpg" /> </a></div></div>
                    <div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-6.1.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-6.1.jpg';"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-6.1.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-6.1.jpg" /> </a></div></div>
                    <div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-.jpg';"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-.jpg" /> </a></div></div>
                    <div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-6.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-6.jpg';"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-6.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-6.jpg" /> </a></div></div>
                    <div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-7.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-7.jpg';"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-7.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-7.jpg" /> </a></div></div>
                    <div class="blank5px"></div><div class="pro_chf_photo_more_item"><div class="img50px"><a href="javascript:void(0);" onmouseover="javascript:document.getElementById('proPicView').src='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-8.jpg';document.getElementById('proPicView').width='500';document.getElementById('proPicView').height='500';document.getElementById('hrefProImg').href='/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-8.jpg';"><img src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-8.jpg" width="50" height="50" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL" align="absmiddle" layer-src="/upload/pro/obdstar-x300dp-diagnosis-programmer-key-master-8.jpg" /> </a></div></div>
                </div><script type="text/javascript">
                    layer.config({
                        extend: [
                            'extend/layer.ext.js'
                        ]
                    });
                    layer.ready(function(){
                        layer.photos({
                            photos: '#pro_chf_photo_more',
                            shift: 0,
                            shade:0.7,
                            closeBtn: 1
                        });
                    });
                </script>
            </div>
            <div class="pro_chf_brief">
                <h1>OBDSTAR X300 DP X-300DP PAD Tablet Key Programmer Full Configuration Free Shipping by DHL</h1>
                <div class="blank5px"></div>
                <div class="pro_chf_bri_itemno">Item No. HKSP283<div class="blank5px"></div><span class="gray verdana no_bold">Manufacturer: <a href="/wholesale/brand-obdstar/">OBDSTAR</a></span>
                    <span id="num_pro_sold_51561"></span>
                </div>
                <div class="pro_ch_bf_rate" id="pro_rate_51561"><div class="pro_ch_bf_rate_bg"><div class="pro_ch_bf_rate_vw" style="width:144px;"></div></div><div class="pro_ch_bf_rate_tx">4.8 stars, <a href="/reviews/pro51561" target="_blank">55 reviews.</a></div></div>
                <div class="blank15px"></div>
                <div class="pro_bo_m">
                    <div class="pro_bo_stock_pra">
                        <div class="p_bo_instock">In Stock</div>
                    </div>
                    <div id="ProPriDisp_pd_51561"><div id="ProMultiCurrRef" style="display:none;"><div class="curr_pro_ref">
                                <a href="javascript:void(0);" onclick="CountryCurrencyInitialize('USD'); return false;"><img src="/images/ico_currency/USD.gif" alt="USD">USD 999.00</a>
                                <a href="javascript:void(0);" onclick="CountryCurrencyInitialize('EUR'); return false;"><img src="/images/ico_currency/EUR.gif" alt="EUR">EUR 849.15</a>
                                <a href="javascript:void(0);" onclick="CountryCurrencyInitialize('GBP'); return false;"><img src="/images/ico_currency/GBP.gif" alt="GBP">GBP 779.22</a>
                                <a href="javascript:void(0);" onclick="CountryCurrencyInitialize('AUD'); return false;"><img src="/images/ico_currency/AUD.gif" alt="AUD">AUD 1,278.72</a>
                                <a href="javascript:void(0);" onclick="CountryCurrencyInitialize('JPY'); return false;"><img src="/images/ico_currency/JPY.gif" alt="JPY">JPY 110,889</a>
                            </div></div>
                        <span class="pro_pri_tit_vip">Buy It Now:</span><span class="pro_pri_curr_vip" name="cc_v_USD" style="display:">$999.00</span>
                        <span class="pro_pri_curr_vip" name="cc_v_EUR" style="display:none;">&euro;849.15</span>
                        <span class="pro_pri_curr_vip" name="cc_v_GBP" style="display:none;">&pound;779.22</span>
                        <span class="pro_pri_curr_vip" name="cc_v_AUD" style="display:none;">AU$1,278.72</span>
                        <span class="pro_pri_curr_vip" name="cc_v_JPY" style="display:none;">&yen;110,889</span>
                        <div class="pro_pri_mpr" id="ProMultiCurrTrig" onmouseover="javascript:ProMultiPriceRef('ProMultiCurrRef', 'ProMultiCurrTrig');"></div>
                    </div><script type="text/javascript">ProPeriodPriceReset('51561', 'ProPriDisp_pd_51561', 'ProDetail');</script>			<div class="pro_b_item" id="id_pro_b_item_oQty">
                        <div class="pro_bitm_tit">Quantity:</div>
                        <div class="pro_bitm_cont">
                            <input name="oQty" type="text" class="input" id="oQty" size="4" maxlength="6" onkeypress="event.returnValue=IsDigit();" value="1" onkeyup="ProQtySubTotal(this,'1','999.00','txtSingleProSubTotal','Subtotal: ');IsOrderNeedQty('Y','oQty');" /><span class="px11"></span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="txtSingleProSubTotal" class="px12 verdana"></span>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="blank10px"></div>
                    <div class="exh_m_bri">Free Shipping Promotion for 2017 New & Hot sale Auto Key Programmer<br>Valid time: 10th to 20th August, Shopping Now!</div><div class="blank10px"></div>
                    <div class="pro_bo_add_l"><input name="btn_buyitnow" type="button" class="btn_buyitnow" value="" title="Buy It Now" onclick="javascript:ShoppingCartAdd('51561','BuyItNow','','oSize','','oColor','Y','oQty');return false;" onmouseover="javascript:IsOrderNeedSize('','oSize');IsOrderNeedColor('','oColor');IsOrderNeedQty('Y','oQty');return false;" /></div>
                    <div class="pro_bo_add_m"><input name="add_to_cart" type="button" class="btn_addtocart" value="" title="Add to Cart" onclick="javascript:ShoppingCartAdd('51561','Single','','oSize','','oColor','Y','oQty');return false;" onmouseover="javascript:IsOrderNeedSize('','oSize');IsOrderNeedColor('','oColor');IsOrderNeedQty('Y','oQty');return false;" /></div>
                    <div class="pro_bo_add_r"><input name="add_to_favorites" type="button" class="btn_add_to_favorites" value="" onclick="javascript:AddToFavorites('51561','txt_r_addToFavorites');return false;" /><span id="txt_r_addToFavorites"></span></div>
                    <div class="blank5px"></div>
                </div>
                <div class="blank10px"></div>
                <dl>
                    <dt class="w100px">Shipping:</dt>
                    <dd class="w420px">
                        <strong class="px14 green_dark">Free Shipping</strong>&nbsp;&nbsp;&nbsp;Express Shipping Service&nbsp;<br />			<span class="px11 verdana gray_dark">Estimated delivery time: 3-5 Days.<a href="/support/how-we-ship-the-item-to-you-4072.html" target="_blank"><span class="px10">See details &raquo;</span></a></span>		</dd>
                    <dt class="w100px">Weight:</dt>
                    <dd class="w420px">3.5KG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="gray_dark">( 7.72LB )</span></dd>
                    <dt class="w100px">Package:</dt>
                    <dd class="w420px">39cm*30cm*12cm&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="gray_dark">( Inch:15.35*11.81*4.72 )</span>
                    </dd>
                    <dt class="w100px">Returns:</dt>
                    <dd class="w420px">Return for refund within 7 days,buyer pays return shipping.<a href="/support/return-policy-4174.html" target="_blank"><span class="px11 verdana">Read details »</span></a></dd>
                </dl>
                <div class="blank10px"></div><div class="dashed5px"></div>
                <div class="line18em"><b class="green_dark">Related Download Files:</b><br />&nbsp;&nbsp;<a href="/upload/pro/obdstar-x300dp-register-guide.pdf" target="_blank"><b><img src="/images/ico/download.gif" align="absmiddle" border="0" hspace="5" />obdstar-x300dp-register-guide.pdf</b></a>&nbsp;&nbsp;<span class="px11 gray">(710.9K)</span></a><br />&nbsp;&nbsp;<a href="/upload/pro/obdstar-x300-dp-user-manual.pdf" target="_blank"><b><img src="/images/ico/download.gif" align="absmiddle" border="0" hspace="5" />obdstar-x300-dp-user-manual.pdf</b></a>&nbsp;&nbsp;<span class="px11 gray">(6,727.1K)</span></a><br />&nbsp;&nbsp;<a href="/upload/pro/obdstar-x300dp-upgrade-guide.pdf" target="_blank"><b><img src="/images/ico/download.gif" align="absmiddle" border="0" hspace="5" />obdstar-x300dp-upgrade-guide.pdf</b></a>&nbsp;&nbsp;<span class="px11 gray">(262.5K)</span></a></div>
                <div class="blank5px"></div>
                <div class="dashed5px"></div>
                <div class="pro_ch_bf_digg">
                    <div class="pro_digg_180x35"><a href="javascript:ProDiggIt('51561','sv_pro_digg_51561');"><span id="num_pro_digg_51561"></span></a><span id="sv_pro_digg_51561" class="alert"></span></div>
                </div>
                <div class="blank5px"></div>
                <div class="dashed5px"></div>
                <div class="pro_ch_bf_g_plusone"><g:plusone></g:plusone>
                </div>
<!--                <div class="pro_ch_bf_share">-->
<!--                    <div class="addthis_toolbox addthis_default_style ">-->
<!--                        <a class="addthis_button_preferred_1"></a>-->
<!--                        <a class="addthis_button_preferred_2"></a>-->
<!--                        <a class="addthis_button_preferred_3"></a>-->
<!--                        <a class="addthis_button_preferred_4"></a>-->
<!--                        <a class="addthis_button_preferred_5"></a>-->
<!--                        <a class="addthis_button_preferred_6"></a>-->
<!--                        <a class="addthis_button_preferred_7"></a>-->
<!--                        <a class="addthis_button_preferred_10"></a>-->
<!--                        <a class="addthis_button_preferred_11"></a>-->
<!--                        <a class="addthis_button_preferred_12"></a>-->
<!--                        <a class="addthis_button_compact"></a>-->
<!--                        <a class="addthis_counter addthis_bubble_style"></a>-->
<!--                    </div>-->
<!--                    <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4eb4e0b80c259670"></script>-->
<!--                    <div class="blank5px"></div>-->
<!--                    <div class="dashed5px"></div>-->
<!--                    <div class="align_center"><img src="/images/ico/s4.gif" hspace="3" border="0" align="absmiddle" />Any Questions? <a href="/service/obdstar-x300-dp-vs-xtool-x100-pad-2-vs-ci600-plus-8777.html"><strong class="px13">Get Technical Support.</strong></a></div>-->
<!--                    <div class="blank5px"></div>-->
<!--                </div>-->
                <form method="post" name="formOrderAdd" id="formOrderAdd" action="/app/order.asp">
                    <input type="hidden" name="ProID" value="" />
                    <input type="hidden" name="oSize" value="" />
                    <input type="hidden" name="oColor" value="" />
                    <input type="hidden" name="oQty" value="" />
                    <input type="hidden" name="Action" value="" />
                    <input type="hidden" name="AddMethod" id="AddMethod" value="AddItToCart" />
                    <input type="submit" style="display:none" />
                </form>
            </div>
        </div>
        <div class="blank10px"></div><div class="blank10px"></div>
        <div class="w95per">
            <fieldset class="sec">
                <legend><b class="px14 red_dark">Buy more related tools and Save more!</b></legend>
                <div class="pro_list">
                    <div class="photo"><div class="special"><img src="../images/ico/s_rec.gif" align="absmiddle" alt="Featured"></div><a href="/wholesale/obdstar-x300-pro3-key-master-english-version.html" title="【Ship from US No Tax】OBDSTAR X300 PRO3 X-300 Key Master with Immobiliser + Odometer Adjustment +EEPROM/PIC+OBDII"><img src="/upload/pro/obdstar-x300-pro3-new-180.jpg" width="120" height="120" border="0" hspace="0" vspace="0" alt="【Ship from US No Tax】OBDSTAR X300 PRO3 X-300 Key Master with Immobiliser + Odometer Adjustment +EEPROM/PIC+OBDII" align="absmiddle" /></a></div>
                    <div class="brief_fs_suit">
                        <div class="title"><a href="/wholesale/obdstar-x300-pro3-key-master-english-version.html" target="_blank" title="【Ship from US No Tax】OBDSTAR X300 PRO3 X-300 Key Master with Immobiliser + Odometer Adjustment +EEPROM/PIC+OBDII">【Ship from US No Tax】OBDSTAR X300 PRO3 X-300 Key Master with Immobiliser + Odometer Adjustment +EEPROM/PIC+OBDII</a></div>
                        <b class="px11 gray">(Item No. USHKSK196)</b><br />			X300 PRO3 key master by OBDSTAR Company features with the immobiliser key programming function of SKP900,as well as new function e.g. Odometer adjustment, EEPROM/PIC and OBDII.<br />Its design is fully based on industrial standard, for example, it is designed with bilateral keyboards which make it easy to operate, besides its appearance is processed by special material and reaches to the shockproof level.&nbsp;&nbsp;&nbsp;&nbsp;<a href="/wholesale/obdstar-x300-pro3-key-master-english-version.html" target="_blank"><span>More Details &raquo;</span></a>
                        <div class="blank10px"></div>
                        　<img src="/images/ico/freeshipping.gif" border="0" align="absmiddle" alt="Free Shipping" />
                        <div class="clear"></div>
                    </div>
                    <div class="order_fun_suit">
                        <span class="pro_pri_tit_vip_m">Buy It Now:</span><span class="pro_pri_curr_vip_m" name="cc_v_USD" style="display:">$549.00</span>
                        <span class="pro_pri_curr_vip_m" name="cc_v_EUR" style="display:none;">&euro;466.65</span>
                        <span class="pro_pri_curr_vip_m" name="cc_v_GBP" style="display:none;">&pound;428.22</span>
                        <span class="pro_pri_curr_vip_m" name="cc_v_AUD" style="display:none;">AU$702.72</span>
                        <span class="pro_pri_curr_vip_m" name="cc_v_JPY" style="display:none;">&yen;60,939</span>
                        <div class="blank10px"></div><span class="pro_b_item" id="id_pro_b_item_oQty_suit_48455"><b>Quantity: </b><input name="oQty_suit_48455" type="text" class="input" id="oQty_suit_48455" size="4" maxlength="6" onkeypress="event.returnValue=IsDigit();" value="1" onkeyup="ProQtySubTotal(this,'1','549.00','txt_single_subtotal_suit_48455');IsOrderNeedQty('Y','oQty_suit_48455');" /><span class="px12"></span>　<b><span id="alert_o_need_oQty_suit_48455" class="alert"></span></b>　</span><span id="txt_single_subtotal_suit_48455" class="txt_subt_m"></span></b>
                        <div class="blank5px"></div><a href="javascript:void(0);" onclick="javascript:ShoppingCartAdd('48455','Single','N','oSize_suit_48455','N','oColor_suit_48455','Y','oQty_suit_48455');return false;" title="Add to Cart"><img src="/images/btn/add_to_cart_suit.gif" alt="Add to Cart" border="0" align="absmiddle" /></a>
                        <div class="clear"></div></div>
                    <div class="clear"></div>
                </div>
                <div class="pro_list">
                    <div class="photo"><div class="special"><img src="../images/ico/s_rec.gif" align="absmiddle" alt="Featured"></div><a href="/wholesale/obdstar-x300-dp-standard-configuration.html" title="OBDSTAR X300 DP PAD Tablet Key Programmer Standard Configuration Immobilizer+ Odometer Adjustment+ EEPROM/PIC Adapter +OBDII"><img src="/upload/pro/obdstar-x300-dp-standard-configuration-180.1.jpg" width="120" height="120" border="0" hspace="0" vspace="0" alt="OBDSTAR X300 DP PAD Tablet Key Programmer Standard Configuration Immobilizer+ Odometer Adjustment+ EEPROM/PIC Adapter +OBDII" align="absmiddle" /></a></div>
                    <div class="brief_fs_suit">
                        <div class="title"><a href="/wholesale/obdstar-x300-dp-standard-configuration.html" target="_blank" title="OBDSTAR X300 DP PAD Tablet Key Programmer Standard Configuration Immobilizer+ Odometer Adjustment+ EEPROM/PIC Adapter +OBDII">OBDSTAR X300 DP PAD Tablet Key Programmer Standard Configuration Immobilizer+ Odometer Adjustment+ EEPROM/PIC Adapter +OBDII</a></div>
                        <b class="px11 gray">(Item No. HKSP283-B)</b><br />			OBDSTAR X300 DP is the first tablet of OBDSTAR, which has reached a higher level in key programming and diagnosis. Inheriting from OBDSTAR professional auto programming and advanced diagnosing technology, OBDSTAR X300 DP is characterized by covering wide range of vehicles, featuring powerful function, and providing superior quality. Meanwhile, taking advantage of Android system, OBDSTAR X300 DP integrates more application and service, such as Maintenance Database, remote assistant, and One Key Update etc.&nbsp;&nbsp;&nbsp;&nbsp;<a href="/wholesale/obdstar-x300-dp-standard-configuration.html" target="_blank"><span>More Details &raquo;</span></a>
                        <div class="blank10px"></div>
                        　<img src="/images/ico/freeshipping.gif" border="0" align="absmiddle" alt="Free Shipping" />
                        <div class="clear"></div>
                    </div>
                    <div class="order_fun_suit">
                        <span class="pro_pri_tit_vip_m">Buy It Now:</span><span class="pro_pri_curr_vip_m" name="cc_v_USD" style="display:">$799.00</span>
                        <span class="pro_pri_curr_vip_m" name="cc_v_EUR" style="display:none;">&euro;679.15</span>
                        <span class="pro_pri_curr_vip_m" name="cc_v_GBP" style="display:none;">&pound;623.22</span>
                        <span class="pro_pri_curr_vip_m" name="cc_v_AUD" style="display:none;">AU$1,022.72</span>
                        <span class="pro_pri_curr_vip_m" name="cc_v_JPY" style="display:none;">&yen;88,689</span>
                        <div class="blank10px"></div><span class="pro_b_item" id="id_pro_b_item_oQty_suit_53600"><b>Quantity: </b><input name="oQty_suit_53600" type="text" class="input" id="oQty_suit_53600" size="4" maxlength="6" onkeypress="event.returnValue=IsDigit();" value="1" onkeyup="ProQtySubTotal(this,'1','799.00','txt_single_subtotal_suit_53600');IsOrderNeedQty('Y','oQty_suit_53600');" /><span class="px12"></span>　<b><span id="alert_o_need_oQty_suit_53600" class="alert"></span></b>　</span><span id="txt_single_subtotal_suit_53600" class="txt_subt_m"></span></b>
                        <div class="blank5px"></div><a href="javascript:void(0);" onclick="javascript:ShoppingCartAdd('53600','Single','N','oSize_suit_53600','N','oColor_suit_53600','Y','oQty_suit_53600');return false;" title="Add to Cart"><img src="/images/btn/add_to_cart_suit.gif" alt="Add to Cart" border="0" align="absmiddle" /></a>
                        <div class="clear"></div></div>
                    <div class="clear"></div>
                </div>
                <div class="blank5px"></div>
            </fieldset>
        </div>

        <a name="Specifications"></a>
        <div class="blank10px" id="pro_ctab_star"></div>
        <div class="pro_ctab">
            <ul>
                <li id="p_ab_mn_1" class="current" onclick="AreaMultiMenuShowHide('p_ab_mn_','p_ab_vw_',5,1,'current',''); GotoScrollTop('1', 'pro_ctab_star', 100, '', '', '');"><span>Product Details</span></li>
                <li id="p_ab_mn_2" onclick="AreaMultiMenuShowHide('p_ab_mn_','p_ab_vw_',5,2,'current',''); GotoScrollTop('1', 'pro_ctab_star', 100, '', '', '');"><span>Video</span></li>
                <li id="p_ab_mn_3" onclick="AreaMultiMenuShowHide('p_ab_mn_','p_ab_vw_',5,3,'current','');  GotoScrollTop('1', 'pro_ctab_star', 100, '', '', ''); ProTechService(8777,'p_ab_vw_xy_3');"><span>Tech Support</span></li>
                <li id="p_ab_mn_4" onclick="AreaMultiMenuShowHide('p_ab_mn_','p_ab_vw_',5,4,'current','');  GotoScrollTop('1', 'pro_ctab_star', 100, '', '', ''); PaginationAjax('p_ab_vw_xy_4','/ajax/pro_rev_list.asp','ProID=51561','begin');"><span>Reviews<b id="num_pro_review_51561" class="red_dark"></b></span></li>
                <li><span><a href="/reviews/pro51561#WriteReview">Write a Comment</a></span></li>
                <li onclick="GotoScrollTop('1', 'na_pro_releated', 100, '', '', '');"><span>Related Products</span></li>
                <li id="p_ab_mn_5" onclick="AreaMultiMenuShowHide('p_ab_mn_','p_ab_vw_',5,5,'current',''); GotoScrollTop('1', 'pro_ctab_star', 100, '', '', '');"><span>After-sales Service</span></li>
            </ul><div class="clear"></div>
        </div>
        <div id="p_ab_vw_1" style="display:">
            <div class="blank5px"></div>
            <div class="exh_m_bri">OBDSTAR X300 DP is the first tablet of OBDSTAR, which has reached a higher level in key programming and diagnosis. Inheriting from OBDSTAR professional auto programming and advanced diagnosing technology, X300 DP is characterized by covering wide range of vehicles, featuring powerful function, and providing superior quality. Meanwhile, taking advantage of Android system, X300 DP integrates more application and service, such as Maintenance Database, remote assistant, and One Key Update etc.</div>
            <div class="blank5px"></div>
            <div class="exh_m_cont">
                <h2><strong><span style="font-size:12px">OBDSTAR X300 DP PAD Tablet Key Programmer Full Configuration</span></strong></h2>
                <!--StartFragment --><br />
                <strong><span style="font-size:12px">OBDSTAR X300 DP&nbsp;</span>Update&nbsp;Announcement&nbsp;on&nbsp;July&nbsp;31st</strong><br />
                <br />
                2017-08-03&nbsp;|&nbsp;View:&nbsp;6927<br />
                <br />
                <strong>1.&nbsp;Odometer&nbsp;Reset:</strong><br />
                <br />
                Solve&nbsp;NEC&nbsp;95320&nbsp;MM&nbsp;dash&nbsp;board&nbsp;type&nbsp;odometer&nbsp;reset&nbsp;function&nbsp;defects<br />
                <br />
                Solve&nbsp;NEC&nbsp;24C64_VDO&nbsp;dash&nbsp;board&nbsp;type&nbsp;odometer&nbsp;reset&nbsp;function&nbsp;defects<br />
                <br />
                Solve&nbsp;Sagitar&nbsp;(2007-2010)&nbsp;CDC24C32&nbsp;dash&nbsp;board&nbsp;type&nbsp;odometer&nbsp;reset&nbsp;function&nbsp;defects<br />
                <br />
                Solve&nbsp;NEC24C32&nbsp;dash&nbsp;board&nbsp;type&nbsp;odometer&nbsp;reset&nbsp;defects<br />
                <br />
                Solve&nbsp;W251,&nbsp;W164&nbsp;odometer&nbsp;reset&nbsp;defects<br />
                <br />
                Solve&nbsp;the&nbsp;following&nbsp;models&nbsp;odometer&nbsp;reset&nbsp;function<br />
                <br />
                Crown&nbsp;Victoria&nbsp;(2005&nbsp;-),&nbsp;E250&nbsp;(2008-2009),&nbsp;E350&nbsp;(2008-2009),&nbsp;E450&nbsp;(2008-2009),&nbsp;Escape&nbsp;(2008-2012),<br />
                <br />
                Explorer&nbsp;(2004),&nbsp;F150&nbsp;(2006-2007)&nbsp;F250&nbsp;(2006-2007),&nbsp;F350&nbsp;(2006-2007),&nbsp;F450&nbsp;(2006-2007),<br />
                <br />
                F500&nbsp;(2006-2007),&nbsp;F550&nbsp;(2006-2008),&nbsp;Five&nbsp;Hundred&nbsp;(500))&nbsp;Flex&nbsp;(2008-2012),&nbsp;Focus&nbsp;(2005-2008),&nbsp;<br />
                <br />
                Freestar&nbsp;(2006&nbsp;-),&nbsp;Freestyle&nbsp;(2005-),&nbsp;Merc&nbsp;Mariner&nbsp;(2008&nbsp;-),&nbsp;Town&nbsp;car&nbsp;(2005-),Taurus&nbsp;(2008-2009,&nbsp;2004)<br />
                <br />
                <strong>2.&nbsp;IMMO&nbsp;Remote&nbsp;Control&nbsp;Programming:</strong><br />
                <br />
                Issued&nbsp;VW&nbsp;Touareg&nbsp;IMMO<br />
                <br />
                Issued&nbsp;Audi&nbsp;A6/A7/A8&nbsp;IMMO&nbsp;optimization<br />
                <br />
                Issued&nbsp;Audi&nbsp;Q5/A4L&nbsp;generation&nbsp;5<br />
                <br />
                Optimize&nbsp;Ford&nbsp;Ranger,&nbsp;transit&nbsp;(Transit)&nbsp;IMMO&nbsp;programming&nbsp;(BUG:1337,&nbsp;BUG:1338)<br />
                <br />
                Adding&nbsp;the&nbsp;IMMO&nbsp;system&nbsp;ISO&nbsp;type<br />
                <br />
                <strong>3.&nbsp;Diagnostic&nbsp;Models:</strong><br />
                <br />
                Adding&nbsp;Renault&nbsp;new&nbsp;models:<br />
                <br />
                ALASKAN\AVANTIME\CAPTUR/KAPTUR&nbsp;BR/IN/RU\CAPTUR/QM3/KABIN\CLIO&nbsp;II&nbsp;PH6\CLIO&nbsp;II\CLIO&nbsp;III\CLIO&nbsp;IV\CLIO&nbsp;V6&nbsp;PH2\CLIO&nbsp;V6<br />
                <br />
                CLIOIIP2/3/4\DOKKER/KANGOO\DUSTER&nbsp;PH2\DUSTER\ESPACE&nbsp;IV\ESPACE&nbsp;V\ESPACE\ESPACEIV&nbsp;PH2/3/4\KADJAR&nbsp;CN\KADJAR\KANGOO&nbsp;II,ect.<br />
                <br />
                Adding&nbsp;Daxia&nbsp;new&nbsp;models:<br />
                <br />
                1304_PK_1_POINT_9D\1304_DS_1_POINT_9D\1305_PK_1_POINT_9D\1305_DS_1_POINT_9D\D_POINT__CAB1_POINT_9D\SUPERNOVA<br />
                <br />
                SOLENZA\LOGAN\SANDERO\DUSTER\LODGY\DOKKER,ect.<br />
                <br />
                Adding&nbsp;Renault&nbsp;-&nbsp;Samsung&nbsp;new&nbsp;models:<br />
                <br />
                CAPTUR_QM3_KABIN\CLIO_IV\KOLEOS_II_CN_QM6_CN\KOLEOS_II_QM6\KOLEOS_QM5\LATITUDE_SM5\MEGANE_IV_SEDAN\NEW_SM3_FLUENCE_MEGANE<br />
                <br />
                SAFRANE2_Point_0_SM5_DF\SAFRANE_2_Point_3_SM7_LF\SCALA_SM3_CF,ect.<br />
                <br />
                Adding&nbsp;Mercedes-Benz&nbsp;new&nbsp;models:<br />
                <br />
                CLK-series\E/CLS-series\CLS-series\S/CL/Maybach-&nbsp;series\CL-&nbsp;series\SL/SLR/SLK-&nbsp;series\SLR-&nbsp;series\SLK-&nbsp;series\M/G/GL/GLK-&nbsp;Series\M-series\G-series<br />
                <br />
                GL-series\R-series,ect.<br />
                <br />
                Adding&nbsp;Maybach&nbsp;new&nbsp;models:<br />
                <br />
                240.078&nbsp;MAYBACH&nbsp;57\240.079&nbsp;MAYBACH&nbsp;57S\240.077&nbsp;MAYBACH&nbsp;57&nbsp;S\240.178&nbsp;MAYBACH&nbsp;62\240.179&nbsp;MAYBACH&nbsp;62S/R\240.177&nbsp;MAYBACH&nbsp;62&nbsp;S,etc.<br />
                <br />
                <strong>4.&nbsp;optimization</strong><br />
                <br />
                Optimize&nbsp;VW&nbsp;reset&nbsp;airbag<br />
                <br />
                Optimize&nbsp;VW&nbsp;throttle<br />
                <br />
                Optimize&nbsp;B30&nbsp;VIN&nbsp;all&nbsp;00&nbsp;flashback&nbsp;(1334)<br />
                <br />
                Optimize&nbsp;VW&nbsp;oilrvice&nbsp;reset<br />
                <br />
                Optimize&nbsp;VW&nbsp;steering&nbsp;angle&nbsp;reset<br />
                <br />
                Optimize&nbsp;VW&nbsp;EPB<br />
                <br />
                Optimize&nbsp;VW&nbsp;battery&nbsp;matching<br />
                <br />
                Optimization&nbsp;software&nbsp;(to&nbsp;solve&nbsp;the&nbsp;problem&nbsp;of&nbsp;DP&nbsp;device&nbsp;can&nbsp;not&nbsp;be&nbsp;tested)<br />
                <br />
                First&nbsp;Issue&nbsp;FR&nbsp;language<br />
                <br />
                Solve&nbsp;the&nbsp;error&nbsp;and&nbsp;content&nbsp;returns&nbsp;problem&nbsp;when&nbsp;diagnostic&nbsp;device&nbsp;enters&nbsp;the&nbsp;connection&nbsp;detection<br />
                <br />
                Solve&nbsp;the&nbsp;multiple&nbsp;content&nbsp;coverage&nbsp;APP&nbsp;crash&nbsp;problem<br />
                <br />
                Solve&nbsp;the&nbsp;APP&nbsp;crash&nbsp;problem&nbsp;during&nbsp;software&nbsp;update&nbsp;in&nbsp;Thai&nbsp;language<br />
                <br />
                Solve&nbsp;the&nbsp;VCI.BIN&nbsp;failed&nbsp;to&nbsp;load&nbsp;when&nbsp;double&nbsp;click&nbsp;the&nbsp;diagnostic&nbsp;models&nbsp;list<br />
                <br />
                Remove&nbsp;the&nbsp;password&nbsp;operation&nbsp;to&nbsp;clear&nbsp;fault&nbsp;code&nbsp;<br />
                <br />
                PASU&nbsp;version&nbsp;adds&nbsp;ALTO&nbsp;800&nbsp;ID46&nbsp;(Blank)&nbsp;IMMO&nbsp;system<br />
                <br />
                Optimize&nbsp;Buick&nbsp;Royaum&nbsp;key&nbsp;programming<br />
                <br />
                Optimize&nbsp;Chevrolet&nbsp;Koros<br />
                <br />
                Optimize&nbsp;the&nbsp;Bluetooth&nbsp;communication&nbsp;of&nbsp;Audi&nbsp;Q7,&nbsp;A6L&nbsp;generation&nbsp;4&nbsp;(EEPROM&nbsp;backup)<br />
                <br />
                Optimize&nbsp;NEC&nbsp;24C64&nbsp;read&nbsp;IMMO&nbsp;data&nbsp;algorithm<br />
                <br />
                Optimize&nbsp;Transit&nbsp;IMMO&nbsp;system&nbsp;(BUG:&nbsp;1302)<br />
                <br />
                Solve&nbsp;the&nbsp;system&nbsp;entry&nbsp;failure&nbsp;of&nbsp;Corolla&nbsp;-&nbsp;06&nbsp;/&nbsp;2004-&gt;&nbsp;/&nbsp;Avensis&nbsp;-&nbsp;&lt;-&nbsp;04/2005&nbsp;/&nbsp;LEXUS&nbsp;-&nbsp;Gs430<br />
                <br />
                Optimized&nbsp;510&nbsp;smart&nbsp;key&nbsp;programming&nbsp;function&nbsp;security&nbsp;verification<br />
                <br />
                Key&nbsp;Programming<br />
                <br />
                Adding&nbsp;310&nbsp;Wagon&nbsp;smart&nbsp;key&nbsp;system&nbsp;function&nbsp;support<br />
                <br />
                Added&nbsp;DX3&nbsp;smart&nbsp;key&nbsp;programming&nbsp;function<br />
                <br />
                Addingd&nbsp;Roewe&nbsp;ERX5,&nbsp;I6&nbsp;smart&nbsp;key&nbsp;programming<br />
                <br />
                Added&nbsp;Roewe&nbsp;360&nbsp;smart&nbsp;key&nbsp;programming<br />
                <br />
                Added&nbsp;KWIND&nbsp;model&nbsp;key&nbsp;programming&nbsp;function<br />
                <br />
                5.&nbsp;Injector&nbsp;Code<br />
                <br />
                Adding&nbsp;injector&nbsp;code&nbsp;function&nbsp;new&nbsp;models<br />
                <br />
                Audi<br />
                <br />
                Automatic&nbsp;scanning<br />
                <br />
                Manual&nbsp;selection<br />
                A1<br />
                A2<br />
                A3<br />
                A4<br />
                A5<br />
                A6<br />
                A7<br />
                A8<br />
                CABRIO<br />
                Q3<br />
                Q5<br />
                Q7<br />
                R8<br />
                RS3<br />
                RS5<br />
                S2<br />
                S3<br />
                S5<br />
                TT<br />
                TTRS<br />
                TTS<br />
                Chrysler<br />
                Automatic&nbsp;scanning<br />
                Manual&nbsp;selection<br />
                Cherokee&nbsp;(free&nbsp;light)<br />
                2014<br />
                2015<br />
                Ram&nbsp;3500&nbsp;Pickup<br />
                2011<br />
                2012<br />
                Ram&nbsp;4500/5500<br />
                2011<br />
                2012<br />
                Town&nbsp;&amp;&nbsp;Country<br />
                2011<br />
                300/Magnum/Charger<br />
                2006<br />
                2007<br />
                2008<br />
                2009<br />
                2010<br />
                Challenger<br />
                2008<br />
                2009<br />
                2010<br />
                Commander<br />
                2006<br />
                2007<br />
                2008<br />
                2009<br />
                2010<br />
                Grand&nbsp;Cherokee<br />
                2005<br />
                2006<br />
                2007<br />
                2008<br />
                2009<br />
                2010<br />
                Wrangler&nbsp;(Export)<br />
                2008<br />
                2009<br />
                2010<br />
                <br />
                <strong>OBDSTAR X300 DP Newly Added&nbsp;ODO + IMMO + Fuel Injector + DPF: (Update Announcement on May 27th)</strong><br />
                <br />
                <strong>Odometer Reset:</strong><br />
                1. K line odometer reset Model(M2) for AUDI/VW/SKODA/SEAT are added.<br />
                2. VW Golf 7 models are added.<br />
                3. Chassis W169 for BENZ A serial by OBD are added.<br />
                4. Chassis W245 for BENZ B serial by OBD are added.<br />
                5. Chassis W204 for BENZ C serial by OBD are added.<br />
                6. Chassis W209 for BENZ CLK serial by OBD are added.<br />
                7. Chassis W207(E-COUPE) for BENZ CLK serial by OBD are added.<br />
                8. Chassis W218 for BENZ CLS serial by OBD are added.<br />
                9. Chassis W212 for BENZ E serial by OBD are added.<br />
                10. Chassis X204 for BENZ GLK serial by OBD are added.<br />
                11. Chassis R197 for BENZ SLC serial by OBD are added.<br />
                <br />
                <strong>Fuel Injector(Primary Issuance)</strong><br />
                1. Fuel Injector for Chery models are added.<br />
                2. Fuel Injector for Dongfeng Honda CR-V, CIVIC, SPIRIOR are added.<br />
                3. Fuel Injector for ACCORD, CITY, FIT, ODYSSEY, EVERUS S1, CRIDER<br />
                4. Fuel Injector for Acura are added.<br />
                5. Fuel Injector for Honda models are added.<br />
                6. Fuel Injector for Changcheng 4D20 Boshi Diesel Engine, 4D20 Delphi electronic control system, and Liaoning Xinfeng electronic control system.<br />
                7. Fuel Injector for Zhengzhou Nissan Ruiqi ZD28 Engine and ZD25TCR diesel engine.<br />
                <br />
                <strong>Immobilizer:</strong><br />
                The 4th and 5thgeneration for the programming of VW/AUDI/SKODA/SEAT are added as follows:<br />
                1. CDC+24C32 Types<br />
                2. NEC+24C32 Types<br />
                3. 2013 Johnson Types;<br />
                4. Motorola 9S12XHZ512 Types;<br />
                5. NEC+24C64 Color Screen- Type 1<br />
                6. NEC+24C64 Color Screen- Type 2<br />
                7. NEC+24C64 White Screen Type<br />
                8. NEC+24C64(VDO -12)Type<br />
                9. NEC+95320 Type<br />
                10. NEC+35XX Type<br />
                11. Magotan/ CC Type<br />
                12. Q7/A6L(C6)9S12DT(G)128 Type<br />
                13. Q7/A6L(C6)9S12DT(G)256 Type<br />
                14. Lifan Marvell models are added, which includes Add/Clear Keys, Program/Delete ESCL functions.<br />
                15. Jiangling MU-X models are added as key programming and key clearing.<br />
                <br />
                <strong>DPF Function:</strong><br />
                1. DPF for Renault is added.<br />
                2. DPF for Range Rover Sport 2014 is added<br />
                <br />
                <strong>Newly Add Ford Diagnostic Function.</strong><br />
                <br />
                <strong>Full Configuration:</strong> Immobilizer+ odometer Adjustment+ EEPROM/PIC Adapter+ OBDII+ ABS+ TPS+ SRS Reset+ TPMS(Low Tire) Reset+ Steering Angle Reset+ CVT Learning/Value Reset+ EPB+ Oil/service Reset+ Battery Matching+ Diagnosis (Japanese and Korean Serials) +&nbsp;<strong>Diesel Particulate Filter&nbsp;(Newly Add Function, please update your device online to get it)</strong><br />
                <img alt="" src=" /upload/pro/reset-dpf-1.jpg" style="height:458px; width:720px" /><br />
                <strong>OBDSTAR X300 DP VS&nbsp;OBDSTAR X300 PRO3 in the term of function:&nbsp;</strong><br />
                <br />
                So far OBDSTAR DP Full Package can perform full system diagnosis on Japanese and South Korea vehicles, other vehicles will be added in 2017.&nbsp;<br />
                While&nbsp;OBDSTAR X300 PRO3 does not include diagnostic system yet.<br />
                <br />
                <strong>OBDSTAR X300 DPSoftware Update:</strong>&nbsp;One Key Upgrade, Free Update for One Year.&nbsp;After one year, it will cost 225usd/year.<br />
                &nbsp;<br />
                <strong>Language:&nbsp;</strong>English, simplified Chinese, traditional Chinese, language customization.<br />
                <br />
                <strong>OBDSTAR X300 DP</strong> is the first tablet of OBDSTAR, which has reached a higher level in key programming and diagnosis. Inheriting from OBDSTAR professional auto programming and advanced diagnosing technology, X300 DP is characterized by covering wide range of vehicles, featuring powerful function, and providing superior quality. Meanwhile, taking advantage of Android system, X300 DP&nbsp;integrates more application&nbsp;and service, such as Maintenance Database, remote assistant, and One&nbsp;Key&nbsp;Update etc.<br />
                All in one, nothing is impossible!<br />
                <br />
                OBDSTAR X300 DP is a convenient device, combining Android system, immobilizer, diagnose and special function, which closely follows the global trend and greatly meets the demand of users. In addition, abundant and powerful maintenance database and car testing video have realized easier operation and real success. Furthermore, Remote guide strengthens the communication between end users and technicians, without worries about after -sell service.<br />
                &nbsp;<br />
                Android system is equipped with clear and user-friendly interface.<br />
                Diagnostic function strengthens professionalism in auto key programming.<br />
                Large amount of videos help users to operate it easily.<br />
                Maintenance database offers more powerful data.<br />
                Remote guide achieves zero distance between users and technicians.<br />
                Report center helps mutual improvement of terminal experience and technology.<br />
                One key upgrade realizes with one click.<br />
                Industrial design ensures that the tool works stably under tough environment, such as high or low temperatures.<br />
                Multi-language environment can be applied in different countries and areas
                <h2><span style="font-size:12px"><strong>OBDSTAR X300 DP Car List:</strong></span></h2>
                BENZ, BESTURN, BMW, BRILLIANE, CHANGHE, CHERY, CHRYSLER(CHRYSLER/DODGE/JEEP), DFFENGSHEN, DFPV, FAW, FIAT, FORD/LINCOLN, GEELY/HUAPU/SQYL, GM(BUICK/CADILLAC/CHEVROLET/GMC/HUMMER), GREATWALL, HAFEI, HAWTAI, HIMIKO, HNMAZDA, HONDA/ACURA, HONGQI, HYUNDAI, ISUZU, JAC, JAGUAR, KIA, LANDROVER, LIEBAO, LUFENG, LUXGEN, MASERATI, MAZDA, MITSUBISHI, NISSAN/INFINITI, OPEL, PEUGEOT/CITROEN, PORSCHE, PROTON, QQROS, RENAULT, ROEWE/MG, SGMW, SMART, SSANGYONG, SUBARU, SUZUKI, TJFAW, TOYOTA/LEXUS, VW/AUDI/SKODA/SEAT, YOUNGLOTUS, ZZMAZDA, ZZNISSAN;<br />
                Note: There would be some difference to software in different countries. If need more specific information, pls feel free to contact us or our distributors in your area.
                <h2><span style="font-size:12px"><strong>OBDSTAR X300 DP</strong>&nbsp; <strong>Function:</strong></span></h2>
                Read and clear fault codes;<br />
                Clear key memory;<br />
                Program keys, proximity keys, smart key, flip keys;<br />
                Program after-market and OEM keys;<br />
                Display live data;<br />
                Component actuation;<br />
                Read keys from immobilizer memory<br />
                New ECU programming;<br />
                New mechanical key number programming;<br />
                Vehicle identification key programming;<br />
                Reset ECU&amp; Reset immobilizer;<br />
                New remote controller programming;<br />
                Immo PINCODE reader;<br />
                Mileage adjustment via OBD;<br />
                With full and strong database for the most important vehicle makes;<br />
                VCI diagnose<br />
                One key upgrade via wifi<br />
                Remote assistance<br />
                Built-in repair video<br />
                Report center<br />
                EEPROM chip read and immobilizer initialization;<br />
                EPB(Electric park brake);<br />
                Oil/Service reset;<br />
                Battery matching;<br />
                ABS<br />
                TPS<br />
                SRS reset<br />
                TPMS(low tire)reset<br />
                Steering angle reset<br />
                CVT learning/Value reset<br />
                EEPROM/PIC adapter<br />
                OBDII<br />
                Diagnosis
                <h2><span style="font-size:12px"><strong>OBDSTAR X300 DP Feature:</strong></span></h2>
                1. Powerful Samsung Cortex A9 dual-core processor&nbsp;<br />
                2. 7-inch capacitive touch screen(1280*800) &amp; backit and multi-point LED&nbsp;<br />
                3. 2G RAM and 16G ROM(memory can be extended)&nbsp;<br />
                4. 7000MA lithium-ion battery &amp; 10-hour battery life&nbsp;<br />
                5. Unique ergonomic design and tri-proof case with high security&nbsp;<br />
                6. Cover all functions of X100,X200,X300PRO and VAG-PRO 7. Add diagnostic function of whole-vehicle system<br />
                7. One key upgrading, long-distance diagnosis, more convenient after-sales service.<br />
                <br />
                <strong>OBDSTAR X300 DP Update:</strong><br />
                &nbsp; One Key Update<br />
                &nbsp; <img alt="" src=" /upload/pro/obdstar-x300-dp-update1.jpg" style="height:400px; width:640px" /><br />
                &nbsp; Tap&nbsp;main&nbsp;screen&nbsp;&ldquo;batch&nbsp;update&rdquo;&nbsp;,&nbsp;start&nbsp;downloading&nbsp;and&nbsp;upgrading<br />
                &nbsp;&nbsp; <img alt="" src="/upload/pro/obdstar-x300-dp-update2.jpg" style="height:430px; width:688px" /><br />
                <img alt="" src=" /upload/pro/obdstar-x300-dp-01.jpg" style="height:534px; width:698px" /><br />
                <br />
                <strong>OBDSTAR X300 DP User Manual</strong><br />
                <br />
                Before you use OBSTAR X300 DP,please read the user manual carefully.OBDSTAR X300 DP User Manual include product introduction,preparation<br />
                before using,how to diagnose... you can click <a href="http://www.uobdii.com/upload/pro/obdstar-x300-dp-user-manual.rar"><span style="color:#0000FF"><strong>here</strong></span></a> to download obdstar x300 dp user manual

                <h2><strong><span style="font-size:12px">OBDSTAR X300 DP Reviews:</span></strong></h2>
                <em><strong>Customer 1: </strong></em>Its excellent on honda , including rematching ecu and immo after flat battery , paid for itself on these alone , ive done odd new model fords that other kit has struggled with , honda its excellent , late ford its good , been reliable on hyundai and kia though i use gscan on these now , mazda its very good on . its bailed me out when mainstream units have failed . it has its issues but has paid its way many times over for me.<br />
                <em><strong>Customer 2:</strong></em>I can reset g- key with obdstar, not h- key.Programming h key in Virgin box works fine.For smart H reset, i use Tango.These are European types.<br />
                <em><strong>Customer3:</strong></em>For me , I create the key with 7936 firts with vvdi2 and after I program a flip key (with remote) with a obdstar X300 . Because X300 can&#39;t do all key lost but can add flip key via obd if you have a working key<br />
                &nbsp;
                <h2><span style="font-size:12px"><strong>OBDSTAR X300 DP Screen Display</strong></span></h2>
                <img alt="" src=" /upload/pro/obdstar-x300-dp.jpg" style="height:349px; width:504px" />
                <h2><br />
                    <span style="font-size:12px"><strong>OBDSTAR X300 DP</strong> <strong>Packing List:</strong></span></h2>
                X300 DP Tablet Computer<br />
                5V DC Adapter Power<br />
                12V DV Adapter Power<br />
                Adapter<br />
                Adapter Board<br />
                USB Cable<br />
                OBD15P Main Cable<br />
                Pin adapter<br />
                HONDA-3<br />
                HYUNDAI/KIA-10<br />
                OBD II-16<br />
                KIA-20<br />
                Product Certification<br />
                User&#39;s Manual<br />
                <br />
                &nbsp;		<div class="clear"></div>
                <strong>Scan UOBDII QR code to order anywhere and anytime by mobile phone<br />
                    <img alt="UOBDII QR Code" src="/upload/temp/images/uobdii_qr_code.jpg" style="height:300px; width:300px" /><br />
                    Contact Information:<br />
                    <br />
                    Whatsapp: <strong>+8<span style="font-size:12px">6-13995696053</span></strong></strong>
                <div>Live Support: <a href="http://ls.uobdii.org/chat.php" rel="nofollow" target="_blank">Chat with us online</a></div>

                <div>Email: <a href="mailto:sales@UOBDII.com" rel="nofollow">sales@uobdii.com</a></div>

                <div>Skype: <a href="Skype:Sales@UOBDII.com" rel="nofollow">uobd2net@live.com</a></div>
                <strong>If you have any problem, please do not hesitate to contact us.</strong><br />
                <br />
                <strong>Shipment Note:</strong><br />
                <br />
                If your package shipped by Express Delivery, please give us a valid delivery phone number,&nbsp;and also&nbsp;a full and accurate shipping address.<br />
                <br />
                <strong>How to Buy from UOBD2?</strong><br />
                <br />
                <img alt="how to buy one UOBDII.com" src="/upload/temp/images/shopping-process-on-uobd2.jpg" style="height:133px; width:750px" /><br />
                <br />
                &nbsp;	</div>
        </div>
        <div id="p_ab_vw_2" style="display:none"><a name="Video"></a><div class="blank60px"></div><strong>OBDSTAR X300 Pro3 Program Smart Key For Hyundai Santa</strong><br /><iframe width="560" height="315" src="https://www.youtube.com/embed/9-0c7aAcCV8" frameborder="0" allowfullscreen></iframe><br /><br /><br /><strong>OBDSTAR X300 DP & RFID Adapter Program Key For VW Touareg 2011 </strong><br /><iframe width="560" height="315" src="https://www.youtube.com/embed/TsM2ea3Kwyw" frameborder="0" allowfullscreen></iframe><br /><br /><strong>OBDSTAR X300 DP Program Key For Toyota Coralla All Key Lost</strong><br /><iframe width="560" height="315" src="https://www.youtube.com/embed/1SMe1BOxN_I" frameborder="0" allowfullscreen></iframe><br /><br /><strong>OBDSTAR X300 DP Read Pin Code On Citroen C4 </strong><br /><iframe width="560" height="315" src="https://www.youtube.com/embed/s8aCDgvaCRY" frameborder="0" allowfullscreen></iframe><br /><br /><strong>OBDSTAR X300 DP PAD & OBDSTAR Adapter Program Passat 2013--UOBD2</strong><br /><iframe width="560" height="315" src="https://www.youtube.com/embed/9iJvpGm9DNw" frameborder="0" allowfullscreen></iframe><br /><p>OBDSTAR X300 DP Program Key for Jeep 2016 Cherokee</p><iframe width="560" height="315" src="https://www.youtube.com/embed/QWM00XnAYzQ" frameborder="0" allowfullscreen></iframe><br /><br /><p>OBDSTAR X300 DP do All Key Lost for Toyota G Via OBD2</p><br /><iframe width="560" height="315" src="https://www.youtube.com/embed/0xXLgr7V9H0" frameborder="0" allowfullscreen></iframe></div>
        <div id="p_ab_vw_3" style="display:none"><a name="Service"></a><div class="blank60px"></div><div id="p_ab_vw_xy_3"><div class="loading_img"></div></div></div>
        <div id="p_ab_vw_4" style="display:none"><a name="Reviews"></a><div class="blank30px"></div><div id="p_ab_vw_xy_4"><div class="loading_img"></div></div></div>
        <div id="p_ab_vw_5" style="display:none"><a name="AftersalesService"></a><div class="blank60px"></div><br />
            <strong>Shipping Warranty:<br />
                <br />
                We usually ship goods By DHL, UPS, EMS, Singpost airmail, and HongKong Airmail.</strong><br />
            <br />
            DHL: 3-5 days<br />
            UPS: 5-7 days<br />
            EMS: 10-15 working days<br />
            Singpost/HongKong Airmail: 7- 20 working days. At most 45 days.<br />
            <br />
            If you have not received the goods during the normal time, please contact us for checking&nbsp;the&nbsp;package status&nbsp;timely online or by email: <a href="/info/contact-us/">/info/contact-us/</a><br />
            <br />
            <strong>Warrany Policy:</strong><br />
            &nbsp;
            <table border="1" cellpadding="0" cellspacing="0" style="width:750px">
                <tbody>
                <tr>
                    <td style="height:33px; text-align:center; width:115px">Problem Details</td>
                    <td style="text-align:center; width:123px">Warranty Time</td>
                    <td style="text-align:center; width:381px">Treatment</td>
                    <td style="text-align:center; width:219px">Responsibility for Charge</td>
                    <td style="text-align:center; width:123px">Remark</td>
                </tr>
                <tr>
                    <td rowspan="12" style="height:399px; text-align:center; width:115px">Quality Problem</td>
                    <td rowspan="4" style="text-align:center; width:123px">within 7 days after receiving package</td>
                    <td rowspan="2" style="text-align:center; width:381px">Buyer: Submit a complaint(Mail to sales@uobdii.com ) and Return the items to Seller&#39;s assigned address by EMS or Post.</td>
                    <td style="text-align:center; width:219px">Return Ship cost: Seller</td>
                    <td rowspan="30" style="text-align:center; width:123px">Any costs because of customer&#39;s wrong operation leads to return will be responsible by the buyers.</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Resend ship cost: Seller</td>
                </tr>
                <tr>
                    <td rowspan="2" style="height:67px; text-align:center; width:381px">Seller: If can not repair,exchange a new one (Items must be in new condition with original packaging and accessories.)</td>
                    <td style="text-align:center; width:219px">Repair Charge: Seller</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Replace Parts Charge: Seller</td>
                </tr>
                <tr>
                    <td rowspan="4" style="height:133px; text-align:center; width:123px">within 8-14 days after receiving package</td>
                    <td rowspan="2" style="text-align:center; width:381px">Buyer: Submit a complaint and Return the items to assigned address by EMS or Post for repairing</td>
                    <td style="text-align:center; width:219px">Return Ship cost: Buyer</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Resend ship cost: Seller</td>
                </tr>
                <tr>
                    <td rowspan="2" style="height:67px; text-align:center; width:381px">Seller: If can not repair,exchange a new one (Items must be in new condition with original packaging and accessories.)</td>
                    <td style="text-align:center; width:219px">Repair Charge: Seller</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Replace Parts Charge: Seller</td>
                </tr>
                <tr>
                    <td rowspan="4" style="height:133px; text-align:center; width:123px">within 15 days to 1 year after receiving package</td>
                    <td rowspan="2" style="text-align:center; width:381px">Buyer: Submit a complaint and Return the items to assigned address by EMS or Post for repairing</td>
                    <td style="text-align:center; width:219px">Return Ship cost: Buyer</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Resend ship cost: Buyer</td>
                </tr>
                <tr>
                    <td rowspan="2" style="height:67px; text-align:center; width:381px">Seller: Repair it.</td>
                    <td style="text-align:center; width:219px">Repair Charge: Seller</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Replace Parts Charge: Buyer</td>
                </tr>
                <tr>
                    <td rowspan="2" style="height:77px; text-align:center; width:115px">Lost in the delivery</td>
                    <td rowspan="2" style="text-align:center; width:123px">30 days after shipping</td>
                    <td style="text-align:center; width:381px">Buyer: Submit proof to seller</td>
                    <td style="text-align:center; width:219px">New Product Cost: Seller</td>
                </tr>
                <tr>
                    <td style="height:44px; text-align:center; width:381px">Seller: Contact carrier to ask for Claimant and arrange another shipment to buyer</td>
                    <td style="text-align:center; width:219px">Resend Ship Cost: Seller</td>
                </tr>
                <tr>
                    <td rowspan="2" style="height:89px; text-align:center; width:115px">Customs Problem</td>
                    <td rowspan="2" style="text-align:center; width:123px">30 days after shipping</td>
                    <td style="text-align:center; width:381px">Buyer: Finish customs clearance when import</td>
                    <td rowspan="2" style="text-align:center; width:219px">Customs duties or agent fees: Buyer</td>
                </tr>
                <tr>
                    <td style="height:46px; text-align:center; width:381px">Seller: Try to help buyer to finish customs clearance but not responsible on this.</td>
                </tr>
                <tr>
                    <td rowspan="4" style="height:191px; text-align:center; width:115px">Delivery Problems:<br />
                        broken,incomplete,<br />
                        wrong address</td>
                    <td rowspan="4" style="text-align:center; width:123px">within 7 days after receiving package</td>
                    <td rowspan="2" style="text-align:center; width:381px">Buyer: Report to Seller,and sumbit Complaint to Carrier (DHL,TNT,UPS,EMS,etc..) in 7 days to get a Complaint number and send the number to Seller.After the seller&#39;s perpmit,return the full package in good condition to assigned address by EMS or Post. Caution: The Carrier will not accept Complaint after 7 days.</td>
                    <td style="text-align:center; width:219px">Return Ship cost: Buyer</td>
                </tr>
                <tr>
                    <td style="height:61px; text-align:center; width:219px">Resend ship cost: Buyer</td>
                </tr>
                <tr>
                    <td rowspan="2" style="height:67px; text-align:center; width:381px">Seller: ask for compensation as per the Complaint number from Carrier ,not responsible for any losses after 7 days.</td>
                    <td style="text-align:center; width:219px">Repair Charge: Seller</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Replacement Charge: Buyer</td>
                </tr>
                <tr>
                    <td rowspan="2" style="height:84px; text-align:center; width:115px">Received wrong Items</td>
                    <td rowspan="2" style="text-align:center; width:123px">within 3 days after receiving package</td>
                    <td style="text-align:center; width:381px">Buyer: Report to Seller,and return the full package in good condition to assigned address by EMS or Post in 3 days</td>
                    <td style="text-align:center; width:219px">Return Ship cost: Seller</td>
                </tr>
                <tr>
                    <td style="height:37px; text-align:center; width:381px">Seller: Arrange shipment for the correct items</td>
                    <td style="text-align:center; width:219px">Resend ship cost: Seller</td>
                </tr>
                <tr>
                    <td rowspan="4" style="height:133px; text-align:center; width:115px">Man-made Damage: such as update machine online, dismantle the equipment, and so on</td>
                    <td rowspan="4" style="text-align:center">within 1 year</td>
                    <td rowspan="4" style="text-align:center; width:381px">Buyer: Report to Seller,and return the items for repairing to assigned address by EMS or Post</td>
                    <td style="text-align:center; width:219px">Return Ship cost: Buyer</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Resend ship cost: Buyer</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Repair Charge: Buyer</td>
                </tr>
                <tr>
                    <td style="height:33px; text-align:center; width:219px">Replacement Charge: Buyer</td>
                </tr>
                <tr>
                    <td rowspan="4" style="height:157px; text-align:center; width:115px">Note:</td>
                    <td colspan="3" style="text-align:center; width:723px">1. Warranty Policy only protects Main parts.Other parts are out of our warranty policy.</td>
                </tr>
                <tr>
                    <td colspan="3" style="height:43px; text-align:center; width:723px">2. Before return,please confirm with us. we will give you a shipping address once confirmming the problem. Buyer will be responsible for any risks or costs without our permission.</td>
                </tr>
                <tr>
                    <td colspan="3" style="height:38px; text-align:center; width:723px">3. Buyer needs return the items by cheaper EMS or Post, or we can&#39;t get them because of restrict Customs Policy.</td>
                </tr>
                <tr>
                    <td colspan="3" style="height:41px; text-align:center; width:723px">4. The Warranty Policy fits for all products except some products which state the warranty specially in description.</td>
                </tr>
                </tbody>
            </table>
            <br />
            <span style="color:rgb(0, 0, 255)"><strong>Warranty Item</strong></span><br />
            &nbsp;
            <table border="1" cellpadding="1" cellspacing="1" style="width:500px">
                <tbody>
                <tr>
                    <td>Main Unit for Equipment</td>
                    <td>1 year warranty</td>
                </tr>
                <tr>
                    <td>Machine peripheral equipments and wire</td>
                    <td>No warranty</td>
                </tr>
                <tr>
                    <td>Car diagnostic laptop</td>
                    <td>3 months</td>
                </tr>
                <tr>
                    <td>Data Hard Disk</td>
                    <td>No warranty</td>
                </tr>
                <tr>
                    <td>Car software</td>
                    <td>No warranty</td>
                </tr>
                <tr>
                    <td>Consumables</td>
                    <td>No warranty</td>
                </tr>
                </tbody>
            </table>
            <br />
            <br />
            <span style="color:rgb(0, 0, 255)"><strong>Technical Service:&nbsp;</strong></span><br />
            <br />
            1. If you have technical problem with the product you received from us, please contact us online or by email: <a href="/info/contact-us/">Contact us</a><br />
            2. <strong>Remote help service:</strong> If your problem needs to be solved by remote help by our engineer, please download the teamviewer software, install it on your computer, then give us ID and password for remote help.<br />
            &nbsp;
            <div class="translator-theme-default" id="translator-floating-panel" style="left: 664px; top: 330px; right: auto; bottom: auto; display: none;">
                <div id="translator-floating-panel-button" title="Click to translate">&nbsp;</div>
            </div>

            <div class="translator-theme-default" id="translator-floating-panel" style="left: 7px; top: 241px; right: auto; bottom: auto; display: none;">
                <div id="translator-floating-panel-button" title="Click to translate">&nbsp;</div>
            </div>

            <div class="translator-theme-default" id="translator-floating-panel" style="left: 6px; top: 246px; right: auto; bottom: auto; display: none;">
                <div id="translator-floating-panel-button" title="Click to translate">&nbsp;</div>
            </div>
        </div>
        <div class="goto_top"><a href="javascript:void(0);" rel="nofollow" onclick="GotoScrollTop(1, 'WebPageTop', 40, '', '', ''); return false;">Go to TOP</a></div>
        <div class="blank5px"></div>
        <div class="blank10px" id="na_pro_releated"></div>
        <div id="ProRelated_Pros"></div>
        <script type="text/javascript">
            ProRelatedPros('44080|38857|48457|57702|3154', '6', 'Maybe you also like ...', 'ProRelated_Pros');
        </script>
        <div id="WishProFavorites"></div>
        <div id="WishProVisitedList"></div>
        <script type="text/javascript">
            MyWishPro("Row", "MyFavorites", "WishProFavorites");
            MyWishPro("Row", "VisitedList", "WishProVisitedList");
        </script>
        <div class="blank10px"></div><div class="fc_tags"><b class="px13">Product's Tags:</b>&nbsp;&nbsp; 			<a href="/producttags/original-obdstar.html"><strong>Original OBDSTAR</strong></a>&nbsp;&nbsp;
            <a href="/producttags/ship-from-ca.html">Ship From CA</a>&nbsp;&nbsp;
            <a href="/producttags/free-shipping-key-tool.html"><strong>free shipping key tool</strong></a>&nbsp;&nbsp;
            <div class="clear"></div></div><div class="blank10px"></div>	<div class="blank10px"></div>
        <div class="page_prev_next">
            <div class="prev">Previous: <a href="/wholesale/squ-of68-universal-car-emulator.html">SQU OF68 Universal Car Emulator Mini Parts Big Works</a></div>
            <div class="next">Next: <a href="/wholesale/xhorse-vvdi-mb-bga-tool-benz-infrared-adapter.html">Xhorse VVDI MB BGA TOOL BENZ Infrared Adapter</a></div>
        </div>
        <div class="goto_top"><a href="javascript:void(0);" rel="nofollow" onclick="GotoScrollTop(1, 'WebPageTop', 40, '', '', ''); return false;">Go to TOP</a></div>
        <div class="clear"></div>
    </div>
    <div class="main_bottom"></div>
</div>




