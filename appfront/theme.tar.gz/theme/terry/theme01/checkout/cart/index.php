
<div class="main">
    <div class="page_where_l"><a href="../">Home</a> - Shopping Cart</div><div class="page_where_r"><a href="javascript:history.go(-1);" rel="nofollow">&laquo; Go Back</a></div>
    <div class="blank8px"></div>
    <div class="exh_full_top"></div>
    <div class="exh_full_main">
        <h1>Shopping Cart</h1>
        <div class="blank10px"></div>

        <form action="order.asp" method="post" name="formAddOrder">
            <table class="tab_comm">
                <tr class="tr_head">
                    <td width="120">&nbsp;</td>
                    <td>Product Name</td>
                    <td width="100">Unit Price</td>
                    <td width="100">Qty.</td>
                    <td width="100">Subtotal</td>
                </tr>

                <tr class="tr_info">
                    <td><div class="img100px"><a href="/wholesale/latest-mb-sd-c4-c5-software-hdd.html" title="Newest 500GB V2017.07 MB SD C4/C5 Software HDD For DELL D630 Support WIN7&amp;WIN10 System" target="_blank"><img src="/upload/pro/500gb-mb-sd-connect-compact-c4-software-hdd-180.jpg" width="100" height="100" border="0" hspace="0" vspace="0" alt="Newest 500GB V2017.07 MB SD C4/C5 Software HDD For DELL D630 Support WIN7&amp;WIN10 System" align="absmiddle" /></a></div></td>
                    <td class="align_left gray">
                        <a href="/wholesale/latest-mb-sd-c4-c5-software-hdd.html"><span class="px13">Newest 500GB V2017.07 MB SD C4/C5 Software HDD For DELL D630 Support WIN7&amp;WIN10 System</span></a>
                        <div class="blank10px"></div>
                        Item No. SS195-D7
                        <div class="blank10px"></div><a href="javascript:void(0)" onclick="javascript:OrderRemove(&quot;69820|-|-&quot;)">remove</a>
                    </td>
                    <td>$109.00</td>
                    <td><input name="Q_69820|-|-" id="Q_69820|-|-" type="text" class="input" onkeypress="event.returnValue=IsDigit();" onkeyup="ShowHideUpdateSpan(this,&quot;1&quot;,&quot;txtUpdate0&quot;,&quot;69820|-|-&quot;);" size="4" maxlength="6" value="1" style="width:50px;"><span class="px11" id="txtUpdate0"></span></td>
                    <td><b>$109.00</b></td>
                </tr>

                <tr class="tr_info" id="trShipToCountryChoose">
                    <td colspan="5" class="align_right px11">

                        <span class="px12">Ship to: <b class="blue px12">China</b>.</span>
                        <span id="v_h_country_slt_txt" style="display:">Not right? <a href="javascirpt:void(0);" onclick="VH_Country_Select('show','CN'); return false;">Click here to change.</a> (for estimate shipping cost.)</span>
                        <span id="v_h_country_select" style="display:none"></span>

                        <input name="o_ship_country" id="o_ship_country" type="hidden" value="CN" />
                    </td>
                </tr>

                <tr class="tr_info">
                    <td colspan="5" class="align_right verdana line18em">
                        <b>Items Total: <span class="red_dark"> $109.00 </span></b>&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;<b><span class="green">Free Shipping</span></b>
                        <br />
                        <b class="red px16">Total Sum: $109.00</b>
                    </td>
                </tr>
                <tr class="tr_info">
                    <td colspan="5" class="align_right">
                        <span id="v_apply_couponcode" style="display:"><strong>Coupon Code: </strong><input name="CouponCode" type="text" id="CouponCode" size="15" maxlength="15" style="width:80px; height:18px; margin-top:10px;" />
                                        <input name="button" type="button" class="btn_near" id="button" value="Apply" onclick="javascript:OrderSetCouponCode();" />
                        </span>
                        <span id="v_mark_couponcode" class="px11 gray_dark" style="display:none;">
                                <a href="javascript:void(0);" onclick="document.getElementById('v_apply_couponcode').style.display='';document.getElementById('v_mark_couponcode').style.display='none'; return false;">Click here to change.</a>
                        </span>
                    </td>
                </tr>
            </table>
            <input type="hidden" name="Action" value="" />
            <input type="hidden" name="operateItem" value="" />
            <input type="hidden" name="thisReturnURL" value="http://www.uobdii.com/wholesale/latest-mb-sd-c4-c5-software-hdd.html" />
            <input name="OrderAddItemsYN" type="hidden" value="" />
        </form>
        <div class="blank10px"></div>
        <div class="fl" style="margin-top:10px;"><input name="Continue_Shopping" type="button" class="btn_near btn_mid" value="Continue Shopping" onclick="javascript:window.location.href='http://www.uobdii.com/wholesale/latest-mb-sd-c4-c5-software-hdd.html';return false;" /></div>
        <div class="float_right" style="margin-top:10px;"> -- OR -- <input name="Proceed_to_Checkout" type="button" class="btn_near btn_mid" value="Proceed to Checkout" onclick="javascript:GotoWhereAction('Submit');return false;" /></div>
        <div class="float_right" style="margin-right:10px;">
            <form action="/api_ppec/paypal_ec_redirect.php" method="POST" id="form_jumpto_checkout_papal_ecs">
                <input type="hidden" name="paymentType" value="Sale">
                <input type="hidden" name="currencyCodeType" value="USD" />
                <input type="hidden" name="L_PAYMENTREQUEST_0_NAME0" value="Newest+500GB+V2017%2E07+MB+SD+C4%2FC5+Software+HDD+For+DELL+D630+Support+WIN7%26amp%3BWIN10+System" />
                <input type="hidden" name="L_PAYMENTREQUEST_0_NUMBER0" value="SS195-D7" />
                <input type="hidden" name="L_PAYMENTREQUEST_0_AMT0" value="109.00" />
                <input type="hidden" name="L_PAYMENTREQUEST_0_QTY0" value="1" />
                <input type="hidden" name="L_PAYMENTREQUEST_0_DESC0" value="69820; Free Shipping; %2D; %2D; 275g" />
                <input type="hidden" name="PAYMENTREQUEST_0_ITEMAMT" value="109.00" />
                <input type="hidden" name="PAYMENTREQUEST_0_SHIPPINGAMT" value="0.00">
                <input type="hidden" name="PAYMENTREQUEST_0_AMT" value="109.00">
                <input type="hidden" name="PAYMENTREQUEST_0_CUSTOM" value="0|351041|0.0||0.0|0.00|0|275|http://www.UOBDII.com" />
                <input type="hidden" name="PAYMENTREQUEST_0_SHIPTOCOUNTRYCODE" value="CN" />
                <input type="hidden" name="myOrderProNum" value="0" />
                <input type="hidden" name="LOGOIMG" value="http://www.UOBDII.com/images/logo.png">
                <input name="" type="image" class="ipt_img" src="/images/pay/pp-checkout-logo-large.png" alt="Check out with PayPal" id="myPPECbutton" />
                <div id="myContDiID"></div>
            </form>
            <script type="text/javascript">
                window.paypalCheckoutReady = function () {
                    paypal.checkout.setup('sinpecal_api1.gmail.com', {
                        button: 'myPPECbutton',
                        environment: 'production'
                    });
                };
            </script>
            <script src="/api_ppec/js/checkout.js" async></script>
        </div>
        <div class="blank10px"></div><div class="blank10px"></div><div class="blank10px"></div>
        <br />
        <p style="text-align:justify"><span style="color:#993300"><strong>Continue Shopping:</strong></span>&nbsp;Please click <strong>Continue Shopping</strong>&nbsp;if you have not finish your order. And your present order&nbsp;will not be cleared.<br />
            <span style="color:#993300"><strong>Check out with PayPal:</strong></span> If you&nbsp;wanna&nbsp;finish your&nbsp;order, click this button&nbsp;and&nbsp;<strong>You will be taken directly to PayPal to Check out</strong>.&nbsp;It is <strong>easy, safe and secure</strong>.<br />
            <span style="color:#993300"><strong>Proceed to Checkout:&nbsp;</strong></span>If you are our membership or you want to <strong>check out with Western Union or Bank Transfer</strong>, click this button to finish your order.<br />
            <span style="color:#993300"><strong>Coupon Code:</strong></span> If you&nbsp;wanna use&nbsp;<strong>Coupon Code for Discounts</strong>, please input it into&nbsp;coupon code text field and <strong>click &quot;Apply&quot; button</strong>. <a href="/info/how-to-use-coupon-code-2391.html">How to&nbsp;use coupon code? click here.</a><br />
            <br />
            <br />
            <br />
            &nbsp;</p>
        <div class="clear"></div>
    </div>
</div>
