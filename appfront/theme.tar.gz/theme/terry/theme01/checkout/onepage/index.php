<div class="main">
    <div class="page_where_l"><a href="../">Home</a> - Check Out for Order:&nbsp;&nbsp;Serial No. U2170826416376</div><div class="page_where_r"><a href="javascript:history.go(-1);" rel="nofollow">&laquo; Go Back</a></div>
    <div class="blank8px"></div>


    <div class="exh_full_top"></div>
    <div class="exh_full_main">
        <h1>Check Out for Order:&nbsp;&nbsp;<span class="px14 black">Serial No. U2170826416376</span></h1>


        <div class="blank10px"></div>

        <b class="red_dark px16">You placed an order on our site successfully! </b>

        <div class="blank10px"></div>
        <span id="sRtnGetOrderFormStatus"></span>
        <div class="blank10px"></div>


        <span class="px14">You choosed <b class="blue">PayPal</b> payment.</span> <b>After <span id="id_span_jump_sec" class="red px13">30</span> seconds, the system will redirect to the secure PayPal site to finish your order.</b> If it doesn't work, please click the following corresponding button.<a href="javascript:countGoPay"></a>
        <script type="text/javascript">
            function countGoPay(secs){
                document.getElementById("id_span_jump_sec").innerHTML = secs;
                if(--secs>0) {
                    setTimeout("countGoPay("+secs+")",1000);
                }
                else {
                    document.getElementById("form_jumpto_checkout_papal_ecs").submit();;}
            }
            countGoPay(30);
        </script>


        <div class="blank10px"></div><div class="blank10px"></div>



        <div class="p_order_step">
            <div class="o_stp_s_off" id="m_os_shippingcart" onclick="javascript:AreaShowHide('ar_os_shippingcart');OrderStepCSSswitch('m_os_shippingcart');" style="cursor:pointer"><span class="sn">1</span> &nbsp;Order Details</div>
            <div class="scene_nopadding" id="ar_os_shippingcart" style="display:"><table class="tab_comm">
                    <tr class="tr_head">
                        <td width="110">&nbsp;</td>
                        <td>Product Name</td>
                        <td width="100">Unit Price</td>
                        <td width="100">Qty.</td>
                        <td width="100">Subtotal</td>
                    </tr>


                    <tr class="tr_info">
                        <td><div class="img90px"><a href="/wholesale/latest-mb-sd-c4-c5-software-hdd.html" title="Newest 500GB V2017.07 MB SD C4/C5 Software HDD For DELL D630 Support WIN7&amp;WIN10 System" target="_blank"><img src="/upload/pro/500gb-mb-sd-connect-compact-c4-software-hdd-180.jpg" width="90" height="90" border="0" hspace="0" vspace="0" alt="Newest 500GB V2017.07 MB SD C4/C5 Software HDD For DELL D630 Support WIN7&amp;WIN10 System" align="absmiddle" /></a></div></td>
                        <td class="align_left gray">
                            <a href="/wholesale/latest-mb-sd-c4-c5-software-hdd.html" target="_blank"><span class="px13">Newest 500GB V2017.07 MB SD C4/C5 Software HDD For DELL D630 Support WIN7&amp;WIN10 System</span></a>
                            <div class="blank10px"></div>
                            <span class="gray px12">Item No. SS195-D7</span>

                        </td>
                        <td>$109.00</td>
                        <td>1</td>
                        <td><b>$109.00</b></td>
                    </tr>

                    <tr class="tr_info">
                        <td colspan="5" class="align_right verdana px13 line18em">

                            Items Total: <span class="red_dark">$109.00</span>


                            <br /><span class="green">Free Shipping</span>


                            <div class="blank10px"></div>
                            <b class="red px16" style="border-top:1px solid #CCCCCC; padding-top:5px; padding-left:20px;">
                                Total Sum: $109.00
                            </b>
                            <div class="blank5px"></div>
                        </td>
                    </tr>
                </table></div>
            <div class="clear"></div>
        </div>

        <div class="p_order_step">
            <div class="o_stp_s_off" id="m_os_paymentMethod" onclick="javascript:AreaShowHide('ar_os_paymentMethod');OrderStepCSSswitch('m_os_paymentMethod');" style="cursor:pointer"><span class="sn">2</span> &nbsp;You Choosed Payment Method</div>
            <div class="scene" id="ar_os_paymentMethod" style="display:none"><b>PayPalECS</b></div>
            <div class="clear"></div>
        </div>

        <div class="p_order_step">
            <div class="o_stp_s_off" id="m_os_shippingAddress" onclick="javascript:AreaShowHide('ar_os_shippingAddress');OrderStepCSSswitch('m_os_shippingAddress');" style="cursor:pointer"><span class="sn">3</span> &nbsp;Shipping Address</div>
            <div class="scene px13 line15em" id="ar_os_shippingAddress" style="display:none">
                <div class="float_right"><a href="javascript:void(0);" onclick="javascript:document.formOrderAddressChange.submit();return false;"><b class="px11">Change</b></a></div>
                <form action="/app/order_address.asp" method="post" name="formOrderAddressChange">
                    <input type="hidden" name="addAction" value="editAddress" />
                    <input type="hidden" name="OrderID" value="416376" />
                </form>


                Receiver: 221 2121<br />
                212121<br />
                212121<br />212121, France<br />
                Post Code: 2121<br />
                Phone: 212121<br />


                <div class="blank10px"></div></div>
            <div class="clear"></div>
        </div>

        <div class="p_order_step">
            <div class="o_stp_s_cur"><span class="sn_cur">4</span> &nbsp;Checkout and Payment Details</div>
            <div class="scene">


                <div class="blank5px"></div>
                <label for="PayPalECS">
                    <input name="PaymentMethod" type="radio" id="PayPalECS" value="PayPalECS" checked="checked" onclick="javascript:AreaMultiShowHide('area_pay_method_exp_',3,1);" />

                    <img src="/images/pay/PayPal_mark_60x38.gif" alt="PayPalECS" border="0" align="absmiddle" />&nbsp;&nbsp;<b class="px13 verdana">PayPal Express Checkout　　<span class=gray>the safer, easier way to pay.</span></b>
                </label>



                <div class="blank5px"></div>
                <div style="display:" class="pay_ex_a" id="area_pay_method_exp_1">
                    <img align="right" alt="" border="0" hspace="5" src="/images/pay/pay_remark_paypal.gif" />If you have PayPal account, you can pay your order by your PayPal account.<br />
                    If you don&#39;t have PayPal account, it doesn&#39;t matter. You firstly charge your Paypal with you credit card or bank debit card , then also pay via PayPal.<br />
                    Payment can be submitted in any currency.&nbsp;<br />
                    Our PayPal account is: <b style="font-size: 18px;">sinpecal@gmail.com</b>
                    <div class="blank10px"></div>

                    <form action="/api_ppec/paypal_ec_redirect.php" method="POST" id="form_jumpto_checkout_papal_ecs">
                        <input type="hidden" name="PAYMENTREQUEST_0_INVNUM" value="U2170826416376">

                        <input type="hidden" name="paymentType" value="Sale">


                        <input type="hidden" name="CANCELURL" value="http://www.UOBDII.com/app/order_checkout.asp?OrderSN=U2170826416376">

                        <input type="hidden" name="currencyCodeType" value="USD" />


                        <input type="hidden" name="L_PAYMENTREQUEST_0_NAME0" value="Newest+500GB+V2017%2E07+MB+SD+C4%2FC5+Software+HDD+For+DELL+D630+Support+WIN7%26amp%3BWIN10+System" />
                        <input type="hidden" name="L_PAYMENTREQUEST_0_NUMBER0" value="SS195-D7" />
                        <input type="hidden" name="L_PAYMENTREQUEST_0_AMT0" value="109.00" />
                        <input type="hidden" name="L_PAYMENTREQUEST_0_QTY0" value="1" />
                        <input type="hidden" name="L_PAYMENTREQUEST_0_DESC0" value="69820; 1; %2D; %2D; 275" />


                        <input type="hidden" name="PAYMENTREQUEST_0_ITEMAMT" value="109.00" />
                        <input type="hidden" name="PAYMENTREQUEST_0_SHIPPINGAMT" value="0.00">



                        <input type="hidden" name="PAYMENTREQUEST_0_AMT" value="109.00">

                        <input type="hidden" name="PAYMENTREQUEST_0_CUSTOM" value="0|351041|0.0||0.0|0.00|0|275|http://www.UOBDII.com" />


                        <input type="hidden" name="myOrderProNum" value="0" />

                        <input type="hidden" name="LOGOIMG" value="http://www.UOBDII.com/images/logo.png">

                        <input type="submit" style="display:none" />
                        <input name="" type="image" class="ipt_img" src="/images/pay/pp-checkout-logo-large.png" alt="Check out with PayPal" id="myPPECbutton" />


                        <div style="float:right;" id="myContainer"></div>

                    </form>

                    <script type="text/javascript">
                        window.paypalCheckoutReady = function () {
                            paypal.checkout.setup('sinpecal_api1.gmail.com', {
                                button: 'myPPECbutton',
                                environment: 'production'
                            });
                        };
                    </script>
                    <script src="/api_ppec/js/checkout.js" async></script>



                </div>
                <div class="dashed_line"></div>
                <div class="blank5px"></div>


                <div class="blank5px"></div>
                <label for="Western Union">
                    <input name="PaymentMethod" type="radio" id="Western Union" value="Western Union" onclick="javascript:AreaMultiShowHide('area_pay_method_exp_',3,2);" />

                    <img src="/images/pay/ico_western_union.gif" alt="Western Union" border="0" align="absmiddle" />&nbsp;&nbsp;<b class="px13 verdana">Western Union</b>
                </label>



                <div class="blank5px"></div>
                <div style="display:none" class="pay_ex_a" id="area_pay_method_exp_2">
                    <p><strong>First Name: Donglian<br />
                            Last Name : Xu</strong><br />
                        <strong>City: SHENZHEN</strong><br />
                        <strong>Country:CHINA</strong><br />
                        <strong>Postal Code:518112</strong><br />
                        <strong>Mobile: +</strong><strong>0086-13995696053</strong><br />
                        <strong>Tel: +86-755-28704781</strong><br />
                        <strong>Fax:+86-755-28700303</strong></p>

                    <p>Note: Please make sure leave the Order# in the remark section.<br />
                        After you make the payment, please remember to Sign In &quot;My Account&quot; on our site, and submit the Western Union Money Transfer Control Number (MTCN) on the page of &quot;Submit a Request Ticket&quot;. We will confirm your payment within 24 hours upon the receipt of the money.</p>

                </div>
                <div class="dashed_line"></div>
                <div class="blank5px"></div>


                <div class="blank5px"></div>
                <label for="Bank Transfer">
                    <input name="PaymentMethod" type="radio" id="Bank Transfer" value="Bank Transfer" onclick="javascript:AreaMultiShowHide('area_pay_method_exp_',3,3);" />

                    <img src="/images/pay/ico_hsbc.gif" alt="Bank Transfer" border="0" align="absmiddle" />&nbsp;&nbsp;<b class="px13 verdana">Bank Transfer</b>
                </label>



                <div class="blank5px"></div>
                <div style="display:none" class="pay_ex_a" id="area_pay_method_exp_3">
                    <div><strong>Name of Corporation: Sinoy Electronic Technology HK Limited<br />
                            Account:168-308187-838<br />
                            Bank name:HSBC HongKong<br />
                            Swift Code:HSBCHKHH<br />
                            BANK number:004&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<br />
                            Bank Address:BASEMENT L/G &amp; U/G 673 NATHAN ROAD,MONG KOK,KOWLOON,HONGKONG</strong></div>

                    <p><strong>Sinoy Electronic Technology HK Limited</strong> is&nbsp;the designated bank and transfer the money to the designated account above. The money will arrive in our account in about 2-4business days.<br />
                        <strong>Note: Please make sure leave the Order# in the remark section.</strong><br />
                        After you make the payment, please remember to Sign In &quot;My Account&quot; on our site, and submit a notice about payment on the page of &quot;Submit a Request Ttcket&quot;. We will confirm your payment within 24 hours upon the receipt of the money.</p>

                </div>
                <div class="dashed_line"></div>
                <div class="blank5px"></div>




                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>





    </div>
    <div class="exh_full_bottom"></div>
    <div class="clear"></div>
</div>
