<div class="main">
    <div class="main_left">

        <div class="col_d_t">My Account</div>
        <div class="col_d_m">
            <div class="blank5px"></div>

            <div class="ml_dir ml_dir_cur"><a href="orderList.asp">View My Orders</a></div>
            <div class="ml_dir"><a href="accountSet.asp">Account Settings</a></div>
            <div class="ml_dir"><a href="addressBook.asp">Manage Address Book</a></div>
            <div class="ml_dir"><a href="msg_list.asp">Tickets Center</a></div>
            <div class="ml_dir"><a href="msg_add.asp?DirID=2">Submit a Ticket</a></div>

            <div class="ml_dir"><a href="pro_rev_list.asp">My Products' Reviews</a></div>


            <div class="ml_dir"><a href="my_favorites_list.asp">My Favorites</a></div>


            <div class="blank5px"></div>
        </div>
        <div class="col_d_b"></div>

        <div class="blank10px"></div>



        <div class="fun_column px11 gray word_wrap word_break">
            <div class="clear"></div>
            <b class="px14">Welcome!</b><br />
            <b class="px12">&nbsp;zewe&nbsp;jewew</b><br />
            User ID: 312043814@qq.com<br />
            E-Mail: 312043814@qq.com<br />
            Account Status:<b>Normal</b><br />

            <div class="dashed5px"></div>
            <div class="align_right"><a href="../members/?action=SignOut"><img src="../images/ico/logout.gif" hspace="5" border="0" align="absmiddle" />Sign out</a>&nbsp;&nbsp;</div>
            <div class="clear"></div>
        </div>

        <div class="blank10px"></div>


        <div class="fun_column px11 gray">
            <b class="px14">Need help?</b><br />
            If you have questions or need help with your account, you may goto "<a href="../support" target="_blank">Help</a>" or <a href="../info/?dirid=8" target="_blank">contact us</a> to assist you.
            <div class="clear"></div>
        </div></div>
    <div class="main_scene">
        <div class="exh_top"></div>
        <div class="exh_main">
            <div class="align_right px11 verdana" style="margin-top:-10px;"><a href="../">Home</a> - <a href="../members/">My Account: <b class="red">312043814@qq.com</b></a> - My Orders List</div><div class="blank5px"></div><h1>My Orders List</h1>

            <div class="blank10px"></div>

            <table class="tab_comm">
                <tr class="tr_head">
                    <td>Order No.</td>
                    <td>Total Sum</td>
                    <td>Date</td>
                    <td>Status(Last)</td>
                    <td>Last update</td>
                </tr>


                <tr class="tr_info">
                    <td class="px13 verdana"><a href="javascript:void(0);" onclick="javascript:OrderView(416375);return false;"><b>U2170826416375</b></a></td>
                    <td>$109.00</td>
                    <td class="px11 gray">Sat.&nbsp;Aug 26, 2017</td>
                    <td><font color=#333>Pending</font></td>
                    <td class="px11 gray">Aug 26, 2017&nbsp;&nbsp;6:43:18 PM</td>
                </tr>


                <tr class="tr_info">
                    <td class="px13 verdana"><a href="javascript:void(0);" onclick="javascript:OrderView(416374);return false;"><b>U2170826416374</b></a></td>
                    <td>$389.00</td>
                    <td class="px11 gray">Sat.&nbsp;Aug 26, 2017</td>
                    <td><font color=#333>Pending</font></td>
                    <td class="px11 gray">Aug 26, 2017&nbsp;&nbsp;6:41:37 PM</td>
                </tr>

            </table>


            <div class="page_nav"><form onsubmit="location.replace(&quot?ListPager=9284813,2,&quot+this.PageNumber.value);return false">
                    <div class="fr">
                        <span>1</span>
                    </div>
                    <div class="fl">
                        Total:2 items,&nbsp;15 items/p,&nbsp; Page:<b class=red>1</b>/1,&nbsp;Goto<input type="text" class="line" size=2 name="PageNumber" value="1" /><input align="absmiddle" alt="Go!" type="image" name="imageFieldGoto" src="/images/btn/btn_goIcon.gif">
                    </div><div class=clear></div>
                </form></div>


            <form name="formOrderView" method="post" action="orderView.asp">
                <input type="hidden" name="OrderID" value="" />
            </form>

            <div class="clear"></div>
        </div>
        <div class="exh_bottom"></div>
    </div>
    <div class="main_bottom"></div>
</div>



