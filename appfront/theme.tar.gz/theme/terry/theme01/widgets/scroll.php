<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
?>
<div class="footer_fixed">
	<a id="goTop" class="go_top" href="#gotop" style="display: block;">go to top</a>
	<a class="cus_survey" href="<?= Yii::$service->url->getUrl('customer/contacts'); ?>" title="customer survey" target="_blank">customer survey</a>
	<div class="ph"><a id="goBottom" class="go_bottom" href="#gobottom" >go to bottom</a></div>
</div>