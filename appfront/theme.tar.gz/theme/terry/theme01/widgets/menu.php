<div class="hd_menu hd_menu_home">
    <div class="hd_menu_home_cate">OBD2 Categories</div>
    <div class="hd_menu_brands">
        <div class="hd_wr_nav"><a href="search/search.html"><b>Brands</b></a>
            <ul class="hdbrands">
                <a href="wholesale/brand-xhorse/brand-xhorse.html"><img src="upload/brand/logo_xhorse_120x40.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="Xhorse" align="absmiddle" /></a><a href="wholesale/brand-obdstar/brand-obdstar.html"><img src="upload/brand/2016042882959489.png" width="120" height="23" border="0" hspace="0" vspace="0" alt="OBDSTAR" align="absmiddle" /></a><a href="wholesale/brand-xtool/brand-xtool.html"><img src="upload/brand/logo_xtool_120x40.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="Xtool" align="absmiddle" /></a><a href="wholesale/brand-xtuner/brand-xtuner.html"><img src="upload/brand/2016122203679854.png" width="120" height="32" border="0" hspace="0" vspace="0" alt="XTUNER" align="absmiddle" /></a><a href="wholesale/brand-autel/brand-autel.html"><img src="upload/brand/logo_autel_120x40.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="Autel" align="absmiddle" /></a><a href="wholesale/brand-launch-x431/brand-launch-x431.html"><img src="upload/brand/logo_launch_x431_120x40.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="Launch-X431" align="absmiddle" /></a><a href="wholesale/brand-allscanner/brand-allscanner.html"><img src="upload/brand/allscanner-logo.jpg" width="120" height="29" border="0" hspace="0" vspace="0" alt="ALLScanner" align="absmiddle" /></a><a href="wholesale/brand-foxwell/brand-foxwell.html"><img src="upload/brand/foxwell-logo.jpg" width="120" height="40" border="0" hspace="0" vspace="0" alt="Foxwell" align="absmiddle" /></a><a href="wholesale/brand-lishi/brand-lishi.html"><img src="upload/brand/new-lishi-logo.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="LISHI" align="absmiddle" /></a><a href="wholesale/brand-augocom/brand-augocom.html"><img src="upload/brand/augocom-logo.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="AUGOCOM" align="absmiddle" /></a><a href="wholesale/brand-yanhua/brand-yanhua.html"><img src="upload/brand/logo_yanhua_120x40.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="Yanhua" align="absmiddle" /></a><a href="wholesale/brand-creator/brand-creator.html"><img src="upload/brand/2016122901406265.jpg" width="120" height="40" border="0" hspace="0" vspace="0" alt="Creator" align="absmiddle" /></a><a href="wholesale/brand-master/brand-master.html"><img src="upload/brand/logo_master_120x40.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="Master" align="absmiddle" /></a><a href="wholesale/brand-hrt/brand-hrt.html"><img src="upload/brand/logo_hrt_120x40.gif" width="120" height="40" border="0" hspace="0" vspace="0" alt="HRT" align="absmiddle" /></a><a href="wholesale/brand-vxscan/brand-vxscan.html"><img src="upload/brand/2017041870585985.jpg" width="120" height="24" border="0" hspace="0" vspace="0" alt="VXSCAN" align="absmiddle" /></a>					<div class="clear"></div>
            </ul>
        </div>
    </div>
    <div class="hd_menu_nav">
        <a class="" href="producttags/new-arrivals.html">What&#39;s New</a>
        <a class="" href="wholesale/brand-xhorse/brand-xhorse.html">XHORSE</a>
        <a class="" href="producttags/2017-kess-ktag.html"><span id="hd_mn_inf_dir_blink">2017 KESS KTAG</span></a>
        <script type="text/javascript" src="js/hd_mn_blink.js"></script>
        <a class="" href="producttags/vvdi-key-tool.html"><span id="hd_mn_inf_dir_blink">VVDI Key Tool</span></a><script type="text/javascript" src="js/hd_mn_blink.js"></script>
        <a class="" href="producttags/bmw-fem-key-programmer.html">BWM FEM Key Programmer</a>
        <a class=" ms_weekly_special" href="producttags/special-offer.html">Weekly Special</a>
        <a class="" href="service/service.html">Tech Support</a>
        <a class="" href="info/news-notice/news-notice.html">News &amp; Notice</a>
        <a class="" href="info/contact/contact.html">Contact</a>
        <a class="" href="info/payment/payment.html">Payment</a>
    </div>
</div>
<div class="clear"></div>
