<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
?>
<div class="main container one-column">
	<div class="col-main">
		<div>
			
			<span style="font-size:18px;">Your Order Increment Id:</span>
			<span style="font-weight:bold;font-size:18px;color:#cc0000;">#<?= $increment_id ?></span>
			
			<br/><br/>
			Please pay offline and contact customer service to change order payment status
			<br/><br/>
			Thank You!
		</div>
	
	</div>
</div>